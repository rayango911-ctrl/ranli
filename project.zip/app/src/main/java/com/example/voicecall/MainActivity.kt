package com.example.voicecall

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognitionService
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telecom.TelecomManager
import android.telephony.PhoneNumberUtils
import android.telephony.TelephonyManager
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

// ---------- أنواع البيانات ----------

private data class Contact(val name: String, val number: String, val label: String)
private data class Alias(val alias: String, val contact: String, val messenger: String)
private enum class Kind { CALL, WHATSAPP, MESSENGER }
private data class Cmd(
    val kind: Kind,
    val targets: List<String>,
    val speaker: Boolean,
    val number: String?
)

// ---------- أدوات النصوص والمطابقة ----------

private fun normalize(s: String): String {
    val sb = StringBuilder()
    for (c in s) {
        sb.append(
            when (c) {
                in '\u0660'..'\u0669' -> '0' + (c - '\u0660')
                in '\u06F0'..'\u06F9' -> '0' + (c - '\u06F0')
                'أ', 'إ', 'آ' -> 'ا'
                'ة' -> 'ه'
                'ى' -> 'ي'
                'ؤ' -> 'و'
                'ئ' -> 'ي'
                else -> c
            }
        )
    }
    return sb.toString()
        .replace(Regex("[\\u064B-\\u065F\\u0640]"), "")
        .lowercase(Locale.ROOT)
        .replace(Regex("[^\\p{L}\\p{N}+\\s]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
}

private fun similarity(a: String, b: String): Double {
    if (a.isEmpty() || b.isEmpty()) return 0.0
    val dp = IntArray(b.length + 1) { it }
    for (i in 1..a.length) {
        var prev = dp[0]
        dp[0] = i
        for (j in 1..b.length) {
            val tmp = dp[j]
            val cost = if (a[i - 1] == b[j - 1]) 0 else 1
            dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + cost)
            prev = tmp
        }
    }
    return 1.0 - dp[b.length].toDouble() / maxOf(a.length, b.length)
}

private fun score(nameN: String, q: String): Double {
    if (q.length < 2) return 0.0
    if (nameN == q) return 1.0
    if (nameN.contains(q)) return 0.9
    var best = similarity(nameN, q)
    for (t in nameN.split(" ")) {
        best = maxOf(best, similarity(t, q) * 0.95)
    }
    return best
}

private fun variants(n: String): List<String> {
    val out = mutableListOf(n)
    if (n.length > 3 && n.startsWith("ل")) out.add(n.substring(1))
    return out
}

// ---------- الكلمات المفتاحية ----------

private val triggerRegex = Regex("^(ر+ا?ن+\\S*|ابعت\\S*|ارسل\\S*|اتصل\\S*|كلم\\S*)$")
private val whatsappWords = setOf("واتساب", "الواتساب", "واتس", "الواتس", "واتسب", "وتساب", "whatsapp")
private val messengerWords = setOf("ماسنجر", "الماسنجر", "مسنجر", "المسنجر", "ماسنجير", "messenger")
private val speakerWords = setOf("سبيكر", "السبيكر", "speaker", "مكبر", "المكبر")
private val fillerWords = setOf("لي", "على", "ع", "الى", "الي", "رقم", "الرقم", "رساله", "مع")

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var recentBox: LinearLayout
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingListen = false
    private var chooserDialog: AlertDialog? = null
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("ranli", Context.MODE_PRIVATE) }

    private val perms = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.CALL_PHONE
    )

    // ================= الواجهة =================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ar"))
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
            }
        }

        val blue = Color.parseColor("#0A1E78")
        val purple = Color.parseColor("#5A1C8C")
        val red = Color.parseColor("#C8102E")

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 48, 48, 48)
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(blue, purple, red)
            )
        }
        window.statusBarColor = blue
        window.navigationBarColor = red

        val title = TextView(this).apply {
            text = "مساعدك ريان"
            textSize = 34f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, 96, 0, 0)
        }
        val slogan = TextView(this).apply {
            text = "مع ريان حمل نقلتك بأمان"
            textSize = 18f
            setTextColor(Color.parseColor("#E6FFFFFF"))
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 0)
        }
        status = TextView(this).apply {
            text = "اضغط الزر وقل: رنلي على [الاسم]"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 64)
        }
        recentBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(status)
            addView(pill("🎤 احكي", true) { startCommandListening() })
            addView(recentBox)
            addView(pill("⚙️ الأسماء المستعارة وماسنجر", false) { showAliases() }, lp(48))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(content)
        }

        layout.addView(title)
        layout.addView(slogan)
        layout.addView(
            scroll,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(layout)

        refreshRecent()

        if (isVoiceLaunch(intent)) handleLaunch(intent)
        else if (!hasAllPerms()) requestPermissions(perms, 1)
    }

    private fun lp(top: Int = 20): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = top
            gravity = Gravity.CENTER_HORIZONTAL
        }

    private fun pill(label: String, primary: Boolean, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.setAllCaps(false)
        b.textSize = if (primary) 22f else 15f
        b.setTextColor(if (primary) Color.parseColor("#1A1A2E") else Color.WHITE)
        val bg = GradientDrawable()
        bg.setColor(if (primary) Color.WHITE else Color.parseColor("#33FFFFFF"))
        bg.cornerRadius = 100f
        b.background = bg
        val h = if (primary) 96 else 48
        val v = if (primary) 32 else 16
        b.setPadding(h, v, h, v)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun refreshRecent() {
        recentBox.removeAllViews()
        val list = loadRecents()
        if (list.isEmpty()) return
        val head = TextView(this)
        head.text = "آخر المكالمات"
        head.setTextColor(Color.parseColor("#CCFFFFFF"))
        head.gravity = Gravity.CENTER
        head.setPadding(0, 48, 0, 8)
        recentBox.addView(head)
        for (c in list) {
            recentBox.addView(pill("📞 ${c.name}", false) { callContact(c, false) }, lp())
        }
    }

    // ================= إطلاق من السماعة / الاختصار =================

    private fun hasAllPerms() = perms.all {
        checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED
    }

    private fun isVoiceLaunch(i: Intent?): Boolean {
        val a = i?.action
        return a == Intent.ACTION_VOICE_COMMAND ||
            a == Intent.ACTION_ASSIST ||
            a == "android.intent.action.VOICE_ASSIST" ||
            a == "com.example.voicecall.LISTEN" ||
            i?.getBooleanExtra("autolisten", false) == true
    }

    private fun handleLaunch(i: Intent?) {
        if (!isVoiceLaunch(i)) return
        if (hasAllPerms()) {
            startCommandListening()
        } else {
            pendingListen = true
            requestPermissions(perms, 1)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleLaunch(intent)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (pendingListen && hasAllPerms()) {
            pendingListen = false
            startCommandListening()
        }
    }

    // ================= الصوت: نطق واستماع =================

    private fun say(text: String, done: (() -> Unit)? = null) {
        status.text = text
        if (!ttsReady) {
            done?.invoke()
            return
        }
        var finished = false
        val finish = Runnable {
            if (!finished) {
                finished = true
                done?.invoke()
            }
        }
        val id = "u" + System.nanoTime()
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (utteranceId == id) runOnUiThread(finish)
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                if (utteranceId == id) runOnUiThread(finish)
            }
        })
        handler.postDelayed(finish, 12000)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    // ينطق الجملة ثم ينفذ الإجراء (أو ينفذه بعد 4 ثواني بالأكثر)
    private fun sayThen(text: String, action: () -> Unit) {
        var fired = false
        val once = Runnable {
            if (!fired) {
                fired = true
                action()
            }
        }
        handler.postDelayed(once, 4000)
        say(text) {
            handler.removeCallbacks(once)
            once.run()
        }
    }

    // نختار خدمة التعرف الصوتي الحقيقية (مش الفارغة اللي بتخص التطبيق)
    private fun recognizerComponent(): ComponentName? {
        val def = Settings.Secure.getString(contentResolver, "voice_recognition_service")
        val dc = if (def.isNullOrBlank()) null else ComponentName.unflattenFromString(def)
        if (dc != null && dc.packageName != packageName) return dc
        val list = packageManager.queryIntentServices(Intent(RecognitionService.SERVICE_INTERFACE), 0)
        val others = list.filter { it.serviceInfo.packageName != packageName }
        val pick = others.firstOrNull { it.serviceInfo.packageName.contains("google") }
            ?: others.firstOrNull()
        return if (pick == null) null else ComponentName(pick.serviceInfo.packageName, pick.serviceInfo.name)
    }

    private fun startCommandListening() {
        listen { options -> handleSpeech(options) }
    }

    private fun listen(onResult: (List<String>) -> Unit) {
        if (!hasAllPerms()) {
            requestPermissions(perms, 1)
            return
        }
        handler.post {
            recognizer?.destroy()
            val comp = recognizerComponent()
            val created = if (comp != null) {
                SpeechRecognizer.createSpeechRecognizer(this, comp)
            } else {
                SpeechRecognizer.createSpeechRecognizer(this)
            }
            recognizer = created.apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onResults(results: Bundle?) {
                        val list = results
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?: return
                        onResult(list)
                    }
                    override fun onError(error: Int) {
                        status.text = "ما سمعتك، جرب كمان مرة"
                    }
                    override fun onReadyForSpeech(p: Bundle?) { status.text = "عم اسمعك..." }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rms: Float) {}
                    override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onPartialResults(p: Bundle?) {}
                    override fun onEvent(t: Int, p: Bundle?) {}
                })
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-JO") // غيّرها: ar-SA / ar-EG / ar-PS ...
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            recognizer?.startListening(intent)
        }
    }

    // ================= فهم الأمر =================

    private fun parseCommand(raw: String): Cmd? {
        val tokens = normalize(raw).split(" ").filter { it.isNotEmpty() }
        if (tokens.isEmpty() || !triggerRegex.matches(tokens[0])) return null

        var kind = Kind.CALL
        var speaker = false
        val rest = ArrayList<String>()
        for (t in tokens.drop(1)) {
            when {
                t in whatsappWords -> kind = Kind.WHATSAPP
                t in messengerWords -> kind = Kind.MESSENGER
                t in speakerWords -> speaker = true
                else -> rest.add(t)
            }
        }
        val full = rest.joinToString(" ")
        var trimmed: List<String> = rest
        while (trimmed.isNotEmpty()) {
            val t = trimmed.first()
            if (t in fillerWords || (t == "علي" && trimmed.size >= 2)) {
                trimmed = trimmed.drop(1)
            } else {
                break
            }
        }
        val digits = trimmed.joinToString("")
        val number = if (Regex("^\\+?\\d{5,}$").matches(digits)) digits else null
        val targets = listOf(trimmed.joinToString(" "), full).filter { it.isNotEmpty() }.distinct()
        return Cmd(kind, targets, speaker, number)
    }

    private fun handleSpeech(options: List<String>) {
        var cmd: Cmd? = null
        for (raw in options) {
            cmd = parseCommand(raw)
            if (cmd != null) break
        }
        if (cmd == null) {
            status.text = "سمعت: \"${options.firstOrNull() ?: ""}\"\nما فهمت الأمر. قل: رنلي على [الاسم]"
            return
        }
        status.text = "سمعت: \"${options.first()}\""
        execute(cmd)
    }

    private fun execute(cmd: Cmd) {
        if (cmd.kind == Kind.MESSENGER) {
            val al = aliasFor(cmd.targets)
            askMessage { msg -> sendMessenger(al?.messenger, msg) }
            return
        }
        if (cmd.targets.isEmpty() && cmd.number == null) {
            say("مين بدك؟") {
                listen { ans ->
                    val t = ans.firstOrNull()
                    val again = if (t == null) null else parseCommand("رنلي $t")
                    if (again != null) execute(cmd.copy(targets = again.targets, number = again.number))
                }
            }
            return
        }
        val after: (Contact) -> Unit = { c ->
            if (cmd.kind == Kind.WHATSAPP) {
                askMessage { msg -> sendWhatsApp(c.number, msg) }
            } else {
                callContact(c, cmd.speaker)
            }
        }
        val num = cmd.number
        if (num != null) {
            after(Contact(num, num, ""))
            return
        }
        val found = findContacts(queriesFor(cmd.targets))
        when {
            found.isEmpty() -> say("ما لقيت ${cmd.targets.first()} بجهات الاتصال")
            found.size == 1 -> after(found[0])
            else -> chooseContact(found, after)
        }
    }

    // ================= جهات الاتصال =================

    private fun loadContacts(): List<Contact> {
        val out = ArrayList<Contact>()
        contentResolver.query(
            Phone.CONTENT_URI,
            arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER, Phone.TYPE, Phone.LABEL),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0) ?: continue
                val number = c.getString(1) ?: continue
                val label = try {
                    Phone.getTypeLabel(resources, c.getInt(2), c.getString(3)).toString()
                } catch (e: Exception) {
                    ""
                }
                out.add(Contact(name, number, label))
            }
        }
        return out
    }

    // يحوّل الأسماء المستعارة لأسماء جهات الاتصال الحقيقية
    private fun queriesFor(targets: List<String>): List<String> {
        val out = LinkedHashSet<String>()
        val aliases = loadAliases()
        for (t in targets) {
            val n = normalize(t)
            if (n.isEmpty()) continue
            for (v in variants(n)) {
                val al = aliases.firstOrNull { normalize(it.alias) == v }
                if (al != null && al.contact.isNotBlank()) out.add(normalize(al.contact)) else out.add(v)
            }
        }
        return out.toList()
    }

    private fun aliasFor(targets: List<String>): Alias? {
        val aliases = loadAliases()
        for (t in targets) {
            for (v in variants(normalize(t))) {
                val al = aliases.firstOrNull { normalize(it.alias) == v }
                if (al != null) return al
            }
        }
        return null
    }

    private fun findContacts(queries: List<String>): List<Contact> {
        if (queries.isEmpty()) return emptyList()
        val scored = loadContacts().map { c ->
            val nn = normalize(c.name)
            Pair(c, queries.maxOf { score(nn, it) })
        }
        val best = scored.maxOfOrNull { it.second } ?: 0.0
        if (best < 0.72) return emptyList()
        val cutoff = when {
            best >= 1.0 -> 1.0
            best >= 0.9 -> 0.9
            else -> best - 0.08
        }
        val seen = HashSet<String>()
        return scored
            .filter { it.second >= cutoff }
            .sortedByDescending { it.second }
            .map { it.first }
            .filter { seen.add(it.number.filter { ch -> ch.isDigit() }) }
            .take(5)
    }

    // ================= الاختيار بالصوت عند تشابه الأسماء =================

    private fun chooseContact(list: List<Contact>, onChosen: (Contact) -> Unit) {
        val opts = list.take(4)
        val ordinals = listOf("الأول", "التاني", "التالت", "الرابع")
        val labels = opts.map {
            val l = if (it.label.isNotBlank()) " - ${it.label}" else ""
            "${it.name}$l\n${it.number}"
        }
        val spoken = "لقيت ${opts.size} جهات. " +
            opts.indices.joinToString("، ") { "${ordinals[it]} ${opts[it].name} ${opts[it].label}" } +
            ". أي واحد؟"

        var chosen = false
        fun pick(i: Int) {
            if (chosen) return
            chosen = true
            tts?.stop()
            recognizer?.cancel()
            chooserDialog?.dismiss()
            onChosen(opts[i])
        }

        chooserDialog = AlertDialog.Builder(this)
            .setTitle("أي واحد؟")
            .setItems(labels.toTypedArray()) { _, i -> pick(i) }
            .setOnCancelListener {
                chosen = true
                tts?.stop()
                recognizer?.cancel()
            }
            .create()
        chooserDialog?.show()

        say(spoken) {
            if (!chosen) {
                listen { answers ->
                    val idx = parseChoice(answers, opts)
                    if (idx >= 0) pick(idx) else say("ما فهمت، اختار من الشاشة")
                }
            }
        }
    }

    private fun parseChoice(answers: List<String>, opts: List<Contact>): Int {
        for (a in answers) {
            val toks = normalize(a).split(" ")
            fun has(vararg keys: String): Boolean =
                toks.any { t -> keys.any { k -> t.contains(k) } }
            if (has("اول", "واحد", "1")) return 0
            if (has("ثان", "تاني", "اثني", "2")) return 1
            if (has("ثالث", "تالت", "ثلاث", "3")) return 2
            if (has("رابع", "اربع", "4")) return 3
            val hits = opts.indices.filter { i ->
                val on = normalize(opts[i].name + " " + opts[i].label)
                toks.any { t -> t.length > 2 && on.contains(t) }
            }
            if (hits.size == 1) return hits[0]
        }
        return -1
    }

    // ================= الاتصال والرسائل =================

    private fun callContact(c: Contact, speaker: Boolean) {
        addRecent(c)
        sayThen("عم اتصل على ${c.name}") {
            val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(c.number)))
            if (speaker) i.putExtra(TelecomManager.EXTRA_START_CALL_WITH_SPEAKERPHONE, true)
            try {
                startActivity(i)
            } catch (e: SecurityException) {
                status.text = "ما في صلاحية الاتصال"
            }
        }
    }

    private fun askMessage(onMsg: (String) -> Unit) {
        say("شو بدك تقول؟") {
            listen { ans ->
                val m = ans.firstOrNull()?.trim().orEmpty()
                if (m.isNotEmpty()) onMsg(m)
            }
        }
    }

    private fun startFirst(vararg intents: Intent): Boolean {
        for (i in intents) {
            try {
                startActivity(i)
                return true
            } catch (e: ActivityNotFoundException) {
                // جرّب اللي بعده
            }
        }
        return false
    }

    private fun toE164Digits(number: String): String {
        val cleaned = number.filter { it.isDigit() || it == '+' }
        if (cleaned.startsWith("+")) return cleaned.drop(1)
        if (cleaned.startsWith("00")) return cleaned.drop(2)
        val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val iso = tm.simCountryIso?.takeIf { it.isNotBlank() }?.uppercase()
            ?: Locale.getDefault().country
        val e164 = PhoneNumberUtils.formatNumberToE164(cleaned, iso)
        return (e164 ?: cleaned).filter { it.isDigit() }
    }

    private fun sendWhatsApp(number: String, msg: String) {
        val uri = Uri.parse("https://wa.me/" + toE164Digits(number) + "?text=" + Uri.encode(msg))
        val ok = startFirst(
            Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp"),
            Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp.w4b"),
            Intent(Intent.ACTION_VIEW, uri)
        )
        if (ok) {
            Toast.makeText(this, "اضغط إرسال بالواتساب", Toast.LENGTH_LONG).show()
        } else {
            say("ما لقيت الواتساب")
        }
    }

    private fun sendMessenger(username: String?, msg: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("msg", msg))
        val ok: Boolean
        if (!username.isNullOrBlank()) {
            val uri = Uri.parse("https://m.me/$username")
            ok = startFirst(
                Intent(Intent.ACTION_VIEW, uri).setPackage("com.facebook.orca"),
                Intent(Intent.ACTION_VIEW, uri).setPackage("com.facebook.mlite"),
                Intent(Intent.ACTION_VIEW, uri)
            )
            if (ok) Toast.makeText(this, "تم نسخ الرسالة. الصقها بالمحادثة وأرسل", Toast.LENGTH_LONG).show()
        } else {
            val send = Intent(Intent.ACTION_SEND)
            send.type = "text/plain"
            send.putExtra(Intent.EXTRA_TEXT, msg)
            val s1 = Intent(send).setPackage("com.facebook.orca")
            val s2 = Intent(send).setPackage("com.facebook.mlite")
            ok = startFirst(s1, s2)
            if (ok) Toast.makeText(this, "اختار الشخص ثم اضغط إرسال", Toast.LENGTH_LONG).show()
        }
        if (!ok) say("ما لقيت تطبيق الماسنجر")
    }

    // ================= المخزن: آخر المكالمات والأسماء المستعارة =================

    private fun loadRecents(): List<Contact> {
        val s = prefs.getString("recents", null) ?: return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Contact(o.getString("n"), o.getString("p"), o.optString("l"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun addRecent(c: Contact) {
        val list = (listOf(c) + loadRecents().filter { it.number != c.number }).take(3)
        val a = JSONArray()
        for (x in list) {
            a.put(JSONObject().put("n", x.name).put("p", x.number).put("l", x.label))
        }
        prefs.edit().putString("recents", a.toString()).apply()
        refreshRecent()
    }

    private fun loadAliases(): List<Alias> {
        val s = prefs.getString("aliases", null) ?: return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Alias(o.getString("a"), o.optString("c"), o.optString("m"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveAliases(list: List<Alias>) {
        val a = JSONArray()
        for (x in list) {
            a.put(JSONObject().put("a", x.alias).put("c", x.contact).put("m", x.messenger))
        }
        prefs.edit().putString("aliases", a.toString()).apply()
    }

    private fun showAliases() {
        val list = loadAliases()
        val msg = if (list.isEmpty()) {
            "ما في أسماء مستعارة بعد.\nمثال: الشيخ ← أبو محمد"
        } else {
            list.joinToString("\n") {
                val c = if (it.contact.isBlank()) "-" else it.contact
                val m = if (it.messenger.isBlank()) "" else "  (ماسنجر: ${it.messenger})"
                "• ${it.alias} ← $c$m"
            }
        }
        AlertDialog.Builder(this)
            .setTitle("الأسماء المستعارة")
            .setMessage(msg)
            .setPositiveButton("إضافة") { _, _ -> showAddAlias() }
            .setNeutralButton("مسح الكل") { _, _ -> saveAliases(emptyList()) }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun showAddAlias() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(48, 16, 48, 0)
        val fAlias = EditText(this)
        fAlias.hint = "الاسم اللي بتقوله (مثلاً: الشيخ)"
        val fContact = EditText(this)
        fContact.hint = "اسم جهة الاتصال (اختياري)"
        val fMsgr = EditText(this)
        fMsgr.hint = "معرّف ماسنجر أو رابطه (اختياري)"
        box.addView(fAlias)
        box.addView(fContact)
        box.addView(fMsgr)
        AlertDialog.Builder(this)
            .setTitle("إضافة اسم مستعار")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val a = fAlias.text.toString().trim()
                if (a.isNotEmpty()) {
                    val m = fMsgr.text.toString().trim().trimEnd('/')
                        .substringAfterLast('/').substringBefore('?')
                    val kept = loadAliases().filter { normalize(it.alias) != normalize(a) }
                    saveAliases(kept + Alias(a, fContact.text.toString().trim(), m))
                }
                showAliases()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
