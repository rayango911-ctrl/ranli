package com.example.voicecall

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer

// هاي الكلاسات بتخلي "رنلي" يظهر بقائمة "تطبيق المساعد الرقمي" بالإعدادات.
// لما تضغط زر الطاقة مطولاً (أو سماعة البلوتوث)، النظام بيشغّل onShow.

class RanliInteractionService : VoiceInteractionService()

class RanliSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = RanliSession(this)
}

class RanliSession(ctx: Context) : VoiceInteractionSession(ctx) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        val i = Intent(context, MainActivity::class.java)
        i.action = "com.example.voicecall.LISTEN"
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        context.startActivity(i)
        hide()
    }
}

// مطلوب من النظام مع خدمة المساعد، بس ما بنستخدمه للتعرف على الصوت
// (التعرف بيتم عن طريق خدمة جوجل الموجودة بالجهاز).
class RanliRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: RecognitionService.Callback?) {
        try {
            listener?.error(SpeechRecognizer.ERROR_CLIENT)
        } catch (e: Exception) {
            // تجاهل
        }
    }

    override fun onCancel(listener: RecognitionService.Callback?) {}

    override fun onStopListening(listener: RecognitionService.Callback?) {}
}
